package oopmanager;

public class Sequence {
	private int value;
	public int nextVal(){
		value++;
		return value;
	}
}


